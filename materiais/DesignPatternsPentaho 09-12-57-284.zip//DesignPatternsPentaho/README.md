DesignPatternsPentaho
===

